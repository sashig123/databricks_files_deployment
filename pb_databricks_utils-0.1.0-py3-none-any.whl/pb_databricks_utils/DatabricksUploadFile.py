import requests
import base64
import json
from cred import DOMAIN,TOKEN


BASEURL = 'https://%s/api/2.0/dbfs/' % (DOMAIN)

def encodeBase64(file):
  with open(file,'rb') as file:
    data = file.read()
    encoded_data = base64.b64encode(data)
    return(encoded_data)

encoded_file = encodeBase64('D:/PetraBytes/com_petrabytes_seismic-0.1.0-py3-none-any.whl')
# print(encoded_file)
# print(encoded_file.decode())

def createFileHandle(file):
  file_name = file.split('/')[-1]
  response = requests.post(BASEURL+'create',
    headers={'Authorization': 'Bearer %s' % TOKEN},
    json={'path':'dbfs:/libraries/{}'.format(file_name),
    'overwrite':'True'})
  content = json.loads(response.content)
  return(content['handle'])

def addBlock(data):
  response = requests.post(BASEURL+'add-block',
    headers={'Authorization': 'Bearer %s' % TOKEN},
    json={'data' : str(data),
    'handle':1436109125}
    )

# print(createFileHandle(file))
# addBlock(encoded_file)

def getAllFilesList():
  
  response = requests.get(BASEURL+'list',
    headers={'Authorization': 'Bearer %s' % TOKEN},
    json = {'path':'dbfs:/mnt/libraries'})
  content = json.loads(response.content)
  return(content)

print(getAllFilesList())

def putFile(file):
  file_name = file.split('/')[-1]
  response = requests.post(BASEURL+'put',
    headers={'Authorization': 'Bearer %s' % TOKEN},
    json = {"path":"dbfs:/mnt/libraries/{}".format(file_name),
    "contents": encodeBase64(file).decode(),
    "overwrite":"true"})
  content = json.loads(response.content)
  return(content)

# print(putFile('D:/PetraBytes/com_petrabytes_seismic-0.1.0-py3-none-any.whl'))