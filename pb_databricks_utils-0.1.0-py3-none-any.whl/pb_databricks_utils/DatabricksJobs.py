import json
from .cred import DOMAIN,TOKEN
import requests

BASEURL = "https://%s/api/2.0/jobs/" % (DOMAIN)

def createJob(name,notebook,cluster_id=''):
    if cluster_id:
        js = {
        "name": name,
        "existing_cluster_id": cluster_id,
        "notebook_task": {
                "notebook_params": {
                },
            "notebook_path": "/Users/pb-architects@petrabytes.com/Seismic/{}".format(notebook)
            },
        "email_notifications": {
            "on_start": ["lranjan@novelsynth.com","abhyuday@novelsynth.com"],
            "on_success": ["lranjan@novelsynth.com","abhyuday@novelsynth.com"],
            "on_failure": ["lranjan@novelsynth.com","abhyuday@novelsynth.com"]
            },
        "max_concurrent_runs": 10
        }
    else:
        js = {
        "name": name,
        "new_cluster": {
            "spark_version": "7.5.x-scala2.12",
            "node_type_id": "i3.large",
            "spark_env_vars": {
            "PYSPARK_PYTHON": "/databricks/python3/bin/python3"
            },
            "autoscale":{
                "min_workers": 2,
                "max_workers": 8
                },
            },
        "notebook_task": {
            "notebook_params": {
                },
            "notebook_path": "/Users/pb-architects@petrabytes.com/Seismic/{}".format(notebook)
            },
        "email_notifications": {
            "on_start": ["abhyuday@novelsynth.com"],
            "on_success": ["abhyuday@novelsynth.com"],
            "on_failure": ["abhyuday@novelsynth.com"]
            },
        "max_concurrent_runs": 10
        }
   
    response = requests.post(BASEURL+'create',headers={'Authorization': 'Bearer %s' % TOKEN},
    json = js)
    content = json.loads(response.content)
    # return(content)
    return(content['job_id'])
    
# job_id = createJob('Test3','timebased_data_analysis_spark','0219-075733-drab862')
# print(job_id)


def listAllJobs():
    response = requests.get(BASEURL+'list',headers={'Authorization': 'Bearer %s' % TOKEN})
    content = json.loads(response.content)
    job_dict = {}
    for job in content['jobs']:
        job_dict[job['job_id']] = job['settings']['name']
    return(job_dict)

# all_jobs = listAllJobs()
# print(listAllJobs())

def deleteJob(job_id):
    response = requests.post(BASEURL+'delete',headers={'Authorization': 'Bearer %s' % TOKEN},
    json = {"job_id": job_id}
    )
    return(json.loads(response.content))

# for job in all_jobs:
#     print(deleteJob(job))


def getJobDetails(job_id):
    response = requests.get(BASEURL+'get?job_id={}'.format(job_id),headers={'Authorization': 'Bearer %s' % TOKEN},)
    content = json.loads(response.content)
    return(content)

# print(getJobDetails('1857'))

def runJob(job_id, inline_start,inline_end,xline_start,xline_end,json_filename):
    response = requests.post(BASEURL+'run-now',headers={'Authorization': 'Bearer %s' % TOKEN},
    json = {
        "job_id": job_id,
        "notebook_params"   : {
            'inline_start'  : inline_start,
            'inline_end'    : inline_end,
            'xline_start'   : xline_start,
            'xline_end'     : xline_end,
            'json_filename' : json_filename
                            },
        "timeout_seconds":600})
    content = json.loads(response.content)
    # print(content)
    return(content['run_id'])

# run_id = runJob(1856)
# print(run_id)

def getJobMetadata(run_id):
    response = requests.get(BASEURL+'/runs/get-output?run_id={}'.format(run_id),headers={'Authorization': 'Bearer %s' % TOKEN},)
    content = json.loads(response.content)
    return(content)

def getJobState(run_id):
    state = getJobMetadata(run_id)['metadata']['state']['life_cycle_state']
    return(state)
# content = getJobMetadata('26')
# print(content)

def getResultState(run_id):
    state = getJobMetadata(run_id)['metadata']['state']['result_state']
    return(state)

def exportRun(run_id,out_path):
    response = requests.get(BASEURL + 'runs/export?run_id={}'.format(run_id),headers={'Authorization': 'Bearer %s' % TOKEN},)
    content = response.content
    with open(out_path + '/{}.txt'.format(run_id),'wb') as f:
        f.write(content)

# def getOutput(run_id):
#     response = requests.get(BASEURL+'/runs/get-output?run_id={}'.format(run_id),headers={'Authorization': 'Bearer %s' % TOKEN},)
#     content = json.loads(response.content)

def runSubmit(notebook,cluster_id,inline_start,inline_end,xline_start,xline_end,json_filename):
    response = requests.post(BASEURL + 'runs/submit',headers = {'Authorization':'Bearer %s' % TOKEN},
    json = {
        "run_name": "my spark task",
        "existing_cluster_id": cluster_id,
        # "new_cluster": {
        # "spark_version": "7.3.x-scala2.12",
        # "node_type_id": "Standard_D3_v2",
        # "num_workers": 10
        # },
    "notebook_task": {
        "base_parameters"   : {
            'inline_start'  : inline_start,
            'inline_end'    : inline_end,
            'xline_start'   : xline_start,
            'xline_end'     : xline_end,
            'json_filename' : json_filename
                            },
        "notebook_path": "/Users/pb-architects@petrabytes.com/Seismic/{}".format((notebook))
        },
        "email_notifications": {
            "on_start"      : ["abhyuday@novelsynth.com"],
            "on_success"    : ["abhyuday@novelsynth.com"],
            "on_failure"    : ["abhyuday@novelsynth.com"]
                            },
        "timeout_seconds":600
    })
    content = json.loads(response.content)
    return(content['run_id'])