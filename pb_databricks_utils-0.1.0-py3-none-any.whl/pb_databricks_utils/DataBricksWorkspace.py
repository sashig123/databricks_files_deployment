import json
from .cred import DOMAIN,TOKEN
import requests

BASEURL = "https://%s/api/2.0/workspace/" % (DOMAIN)

def getContent(file):
    fs = open(file,mode='rb')
    content = fs.read()
    return(content)

def listAllNotebooks(user = "/Users/pb-developer1@petrabytes.com"):
    response = requests.get(BASEURL+'list',headers={'Authorization': 'Bearer %s' % TOKEN},
    json = {
            "path": user
        })
    contents = json.loads(response.content)
    # for object in content['objects']:
    #     print(object['path'])
    notebooks = [content['path'] for content in contents['objects']]
    return(notebooks)

# print(listAllNotebooks())

def importNotebook(notebook):
    content = getContent(notebook)
    response = requests.post(BASEURL+'import',headers={'Authorization': 'Bearer %s' % TOKEN},
    json = {
        "content": "MSsx",
        "path": "/Users/pb-developer1@petrabytes.com/{}".format(notebook),
        "language": "PYTHON",
        "overwrite": True,
        'content': content.decode(),
  "format": "SOURCE"
})

# importNotebook('blgz_code_example1')

def exportNotebook(notebook):
    response = requests.get(BASEURL+'export',headers={'Authorization': 'Bearer %s' % TOKEN},
    json = {
        "path": "/Users/pb-developer1@petrabytes.com/{}".format(notebook),
        "format": "SOURCE"
        })
    text = json.loads(response.content)
    content = text['content']
    content64 = content.encode('ascii')
    fs = open(notebook,mode='wb')
    fs.write(content64)
    fs.close()

# exportNotebook('blgz_code_example1')



# print(getContent('C:/Users/abdy/Documents/Workspace/Databricks/blgz_code_example1.txt'))
