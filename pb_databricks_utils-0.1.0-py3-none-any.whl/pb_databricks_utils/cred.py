# DOMAIN = 'adb-2599511302904625.5.azuredatabricks.net'
# TOKEN = 'dapi62bd473732710d475923779849cded02-2'

# DOMAIN = 'adb-4897092967212341.1.azuredatabricks.net'
# TOKEN = 'dapi7262bf2a1a1f10f5b4e20f5d2465493a'

#CreateCred.py 
#Creates a credential file. 
# from cryptography.fernet import Fernet 
# import ctypes 
# import time 
# import os 
# import sys 
# import base64
   
# class Credentials(): 
   
#     def __init__(self):
#         self.__domain = ''
#         self.__token = ''
#         self.__token_file = 'key.key'
#         self.__time_of_exp = -1
   
# #---------------------------------------- 
# # Getter setter for attributes 
# #---------------------------------------- 
    
#     @property
#     def domain(self): 
#         return self.__domain 
   
#     @domain.setter 
#     def domain(self,domain): 
#         while (domain == ''): 
#             domain = input('Enter a proper domain name, blank is not accepted:') 
#         self.__domain = domain 
   
#     @property
#     def token(self): 
#         return self.__token 
   
#     @token.setter 
#     def token(self,token): 
#         self.__token = Fernet.generate_key() 
#         f = Fernet(self.__token) 
#         self.__token = f.encrypt(base64.urlsafe_b64encode(token.encode()))
#         del f 
   
#     @property
#     def expiry_time(self): 
#         return self.__time_of_exp 
   
#     @expiry_time.setter 
#     def expiry_time(self,exp_time): 
#         if(exp_time >= 2): 
#             self.__time_of_exp = exp_time 
   
   
#     def create_cred(self): 
#         """ 
#         This function is responsible for encrypting the token and create  key file for 
#         storing the key and create a credential file with user name and token 
#         """
   
#         cred_filename = 'CredFile.ini'
   
#         with open(cred_filename,'w') as file_in: 
#             file_in.write("#Credential file:\ndomain={}\ntoken={}\nExpiry={}\n"
#             .format(self.__domain,self.__token,self.__time_of_exp)) 
#             file_in.write("++"*20) 
   
   
#         #If there exists an older key file, This will remove it. 
#         if(os.path.exists(self.__token_file)): 
#             os.remove(self.__token_file) 
   
#         #Open the Key.key file and place the key in it. 
#         #The key file is hidden. 
#         try: 
   
#             os_type = sys.platform 
#             if (os_type == 'linux'): 
#                 self.__token_file = '.' + self.__token_file 
   
#             with open(self.__token_file,'w') as key_in: 
#                 key_in.write(self.__token.decode())
#                 #Hidding the key file. 
#                 #The below code snippet finds out which current os the scrip is running on and does the taks base on it. 
#                 if(os_type == 'win32'): 
#                     ctypes.windll.kernel32.SetFileAttributesW(self.__token_file, 2) 
#                 else: 
#                     pass
   
#         except PermissionError: 
#             os.remove(self.__token_file) 
#             print("A Permission error occurred.\n Please re run the script") 
#             sys.exit() 
   
#         self.__domain = "" 
#         self.__token = "" 
#         self.__token_file 
   
   
# def main(): 
   
#     # Creating an object for Credentials class 
#     creds = Credentials() 
   
#     #Accepting credentials 
#     creds.domain = input("Enter domain:") 
#     creds.token = input("Enter token:") 
#     # print("Enter the epiry time for key file in minutes, [default:Will never expire]") 
#     # creds.expiry_time = int(input("Enter time:") or '-1') 
   
#     #calling the Credit 
#     creds.create_cred() 
#     print("**"*20) 
#     # print("Cred file created successfully at {}".format(time.ctime())) 
   
#     if not(creds.expiry_time == -1): 
#         os.startfile('expire.py') 
   
   
#     print("**"*20) 
   
# if __name__ == "__main__": 
#     main() 

DOMAIN = 'dbc-fea6f262-8ef7.cloud.databricks.com'
TOKEN = 'dapi2dc78b65ea05ccf0032c4328d2e359e8'