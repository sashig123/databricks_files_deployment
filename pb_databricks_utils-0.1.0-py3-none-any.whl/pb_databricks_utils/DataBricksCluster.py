import requests
from .cred import DOMAIN,TOKEN
import json
import time

BASEURL = "https://%s/api/2.0/clusters/" % (DOMAIN)
# DOMAIN = 'adb-4897092967212341.1.azuredatabricks.net'
# TOKEN = 'dapi7262bf2a1a1f10f5b4e20f5d2465493a'
def createSingleNodeCluster(name):
    response = requests.post(BASEURL+'create',headers = {'Authorization':'Bearer %s' % TOKEN},
    json = {
        "cluster_name": name,
        "cluster_mode":"single_node_cluster",
        "spark_version": "7.5.x-scala2.12",
        "node_type_id": "Standard_D3_v2",
        "spark_env_vars": {
        "PYSPARK_PYTHON": "/databricks/python3/bin/python3"
        },
        "num_workers":0}
)

def createCluster(name = 'seismic_cluster', min_workers = 2,max_workers = 8,autotermination_minutes = 30,node_type_id = 'Standard_D3_v2'):
    response = requests.post(
    BASEURL + 'create',
    headers={'Authorization': 'Bearer %s' % TOKEN},
    json={
            "cluster_name": name,
            "spark_version": "7.6.x-scala2.12",
            "node_type_id": node_type_id,
            "spark_env_vars": {
            "PYSPARK_PYTHON": "/databricks/python3/bin/python3"
            },
            "autoscale":{
                "min_workers":min_workers,
                "max_workers":max_workers
            },         
            "autotermination_minutes": autotermination_minutes
            }
        )
    print(response.status_code)
    if response.status_code == 200:
        return("Creating cluster with ID: %s" % response.json()['cluster_id'])
    else:
        return("Error launching cluster: %s: %s" % (response.json()["error_code"], response.json()["message"]))

# print(createCluster('TOKEN'))

def getClusters():
    response = requests.get(BASEURL+'list',
    headers={'Authorization': 'Bearer %s' % TOKEN})
    # print(response.status_code)
    text = json.loads(response.content)
    clusters = {}
    for cluster in text['clusters']:
        clusters[cluster['cluster_name']]  = cluster['cluster_id']
    return(clusters)

# print(getClusters())

def getClusterState(cluster_name):
    clusters = getClusters()
    cluster_id = clusters[cluster_name]
    response = requests.get(BASEURL+'get?cluster_id={}'.format(cluster_id),
    headers = {'Authorization': 'Bearer %s' % TOKEN})
    text = json.loads(response.content)
    # print(text)
    state = text['state']
    return(state)

# print(getClusterState('test_cluster'))

def startCluster(cluster_name):
    clusters = getClusters()
    cluster_id = clusters[cluster_name]
    cluster_state = getClusterState(cluster_name)
    try:
        response = requests.post(BASEURL+'start',
        headers = {'Authorization': 'Bearer %s' % TOKEN},
        json = {
            "cluster_id": cluster_id
            }
        )
        print('Starting cluster "{}", id "{}". This may take sometime...'.format(cluster_name,cluster_id))
        time.sleep(30)
        while cluster_state != 'RUNNING':
            cluster_state = getClusterState(cluster_name)
            time.sleep(15)
        print("Cluster started '{}', id '{}'.".format(cluster_name,cluster_id))
    except Exception as e:
        print(e)

# startCluster('seismic_cluster')

def terminateCluster(cluster_name):
    clusters = getClusters()
    cluster_id = clusters[cluster_name]
    try: 
        response = requests.post(BASEURL+'delete',
        headers = {'Authorization': 'Bearer %s' % TOKEN},
        json = {
            "cluster_id": cluster_id
            }
        )
        print('Terminating cluster with id: ',cluster_id)
    except Exception as e:
        print(e)

# terminateCluster('TOKEN')

def deleteCluster(cluster_name):
    clusters = getClusters()
    cluster_id = clusters[cluster_name]
    try: 
        response = requests.post(BASEURL+'permanent-delete',
        headers = {'Authorization': 'Bearer %s' % TOKEN},
        json = {
            "cluster_id": cluster_id
            }
        )
        print('Permanently deleting cluster with id: ',cluster_id)
    except Exception as e:
        print(e)

# deleteCluster('TOKEN')
def installLibrary(cluster):
    BASEURL = 'https://%s/api/2.0/libraries/' % (DOMAIN)
    response = requests.post( BASEURL+'install',
    headers={'Authorization': 'Bearer %s' % TOKEN},
    json = {"cluster_id":getClusters()[cluster],
    "libraries":[{"whl":"dbfs:/mnt/libraries/com_petrabytes_seismic-0.1.0-py3-none-any.whl"
                }]
            })
    content = json.loads(response.content)
    return(content)